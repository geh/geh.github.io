// Program P6.7
     #include <stdio.h>
     #define MaxNum 100
     int main() {
        void mergeSort(int[], int, int);
        int num[] = {53, 12, 98, 63, 18, 32, 80, 46, 72, 21};
        int n = 10;
        mergeSort(num, 0, n-1);
        for (int h = 0; h < n; h++) printf("%d ", num[h]);
        printf("\n");
     } //end main

     void mergeSort(int A[], int lo, int hi) {
        void merge(int[], int, int, int);
        if (lo < hi) { //list contains at least 2 elements
           int mid = (lo + hi) / 2; //get the mid-point subscript
           mergeSort(A, lo, mid); //sort first half
           mergeSort(A, mid + 1, hi); //sort second half
           merge(A, lo, mid, hi); //merge sorted halves
        }
     } //end mergeSort

     void merge(int A[], int lo, int mid, int hi) {
     //A[lo..mid] and A[mid+1..hi] are sorted;
     //merge the pieces so that A[lo..hi] are sorted
        static int T[MaxNum];
        int i = lo;
        int j = mid + 1;
        int k = lo;
        while (i <= mid || j <= hi) {
           if (i > mid) T[k++] = A[j++];          //A[lo..mid]  completely processed
           else if (j > hi) T[k++] = A[i++];      //A[mid+1..hi]  completely processed
           else if (A[i] < A[j]) T[k++] = A[i++]; //neither part completed
           else T[k++] = A[j++];
        }
        for (i = lo; i <= hi; i++) A[i] = T[i];   //copy merged elements from T to A
     } //end merge
