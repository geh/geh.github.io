     Fraction addFraction(Fraction a, Fraction b) {
        Fraction c;
        c.num = a.num * b.den + a.den * b.num;
        c.den = a.den * b.den;
        return c;
     }

     Fraction subFraction(Fraction a, Fraction b) {
        Fraction c;
        c.num = a.num * b.den - a.den * b.num;
        c.den = a.den * b.den;
        return c;
     }

     Fraction mulFraction(Fraction a, Fraction b) {
        Fraction c;
        c.num = a.num * b.num;
        c.den = a.den * b.den;
        return c;
     }

     Fraction divFraction(Fraction a, Fraction b) {
        Fraction c;
        c.num = a.num * b.den;
        c.den = a.den * b.num;
        return c;
     }
