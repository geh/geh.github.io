//Program P2.5
     #include <stdio.h>
     int main() {
        void makeTable(int, int, int (*fp) (int));
        int square(int);
        makeTable(1, 10, square);
     } //end main

     void makeTable(int first, int last, int (*fp) (int)) {
        for (int h = first; h <= last; h++)
           printf("%2d     %3d\n", h, (*fp)(h));
     } //end makeTable

     int square(int x) {
        return x * x;
     }
