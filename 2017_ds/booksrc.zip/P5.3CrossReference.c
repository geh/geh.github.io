// Program P5.3
     #include <stdio.h>
     #include <ctype.h>
     #include <string.h>
     #define MaxWordSize 20
     #define MaxLine 101

     typedef struct listNode {
        int lineNum;
        struct listNode *next;
     } ListNode, *ListNodePtr;

     typedef struct {
        char word[MaxWordSize+1];
        ListNodePtr firstLine;
     } NodeData;

     typedef struct treeNode {
        NodeData data;
        struct treeNode *left, *right;
     } TreeNode, *TreeNodePtr;

     typedef struct {
        TreeNodePtr root;
     } BinaryTree;

     int main() {
        int getWord(char[], char[]);
        TreeNodePtr newTreeNode(NodeData);
        NodeData newNodeData(char []);
        TreeNodePtr findOrInsert(BinaryTree, NodeData), node;
        ListNodePtr newListNode(int);
        void inOrder(FILE *, TreeNodePtr);

        char word[MaxWordSize+1];
        char line[MaxLine];
        int currentLine = 0;

        FILE * in = fopen("passage.in", "r");
        FILE * out = fopen("passage.out", "w");
        BinaryTree bst;
        bst.root = NULL;

        while (fgets(line, MaxLine, in) != NULL) {
           fprintf(out, "%3d. %s", ++currentLine, line);
           //extract words from the current line
           while (getWord(line, word) != 0) {
              if (bst.root == NULL)
                 bst.root = node = newTreeNode(newNodeData(word));
              else
                 node = findOrInsert(bst, newNodeData(word));
              ListNodePtr ptr = newListNode(currentLine);
              ptr -> next = node -> data.firstLine;
              node -> data.firstLine = ptr;
           }
        }
        fprintf(out, "\nWords                Line numbers\n\n");
        inOrder(out, bst.root);
        fclose(in); fclose(out);
     } // end main

     int getWord(char line[], char str[]) {
     // finds the next word in line and stores it in str
     // returns 1 if a word is found; 0, otherwise
        static int p = 0; //p retains its value between calls to getWord
        char ch;
        int n = 0;
        // skip over non-letters
        while (line[p] != '\0' && !isalpha(line[p])) p++;
        if (line[p] == '\0') return p = 0; //reset p for next line
        str[n++] = tolower(line[p++]);
        while (isalpha(line[p])) {
           if (n < MaxWordSize) str[n++] = tolower(line[p]);
           p++;
        }
        str[n] = '\0';
        return 1;
     } // end getWord

     TreeNodePtr findOrInsert(BinaryTree bt, NodeData d) {
     //searches for d; if found, return pointer to node containing d
     //else insert a node containing d and return pointer to new node
        TreeNodePtr newTreeNode(NodeData);

        if (bt.root == NULL) return newTreeNode(d);
        TreeNodePtr curr = bt.root;
        int cmp;
        while ((cmp = strcmp(d.word, curr -> data.word)) != 0) {
           if (cmp < 0) { //try left
              if (curr -> left == NULL) return curr -> left = newTreeNode(d);
              curr = curr -> left;
           }
           else { //try right
              if (curr -> right == NULL) return curr -> right = newTreeNode(d);
              curr = curr -> right;
           }
        }
        //d is in the tree; return pointer to the node
        return curr;
     } //end findOrInsert

     TreeNodePtr newTreeNode(NodeData d) {
        TreeNodePtr p = (TreeNodePtr) malloc(sizeof(TreeNode));
        p -> data = d;
        p -> left = p -> right = NULL;
        return p;
     } //end newTreeNode

     void inOrder(FILE * out, TreeNodePtr node) {
        void printAWord(FILE *, TreeNodePtr);
        if (node!= NULL) {
           inOrder(out, node -> left);
           printAWord(out, node);
           inOrder(out, node -> right);
        }
     } //end inOrder

     void printAWord(FILE * out, TreeNodePtr pt) {
        void printLineNumbers(FILE *, ListNodePtr);
        fprintf(out, "%-20s", pt -> data.word);
        printLineNumbers(out, pt -> data.firstLine -> next); //print all except first
        fprintf(out, "%3d\n", pt -> data.firstLine -> lineNum); //print first
     } //end printAWord

     void printLineNumbers(FILE * out, ListNodePtr top) {
     //line numbers are in reverse order; print list reversed
        if (top != NULL) {
           printLineNumbers(out, top -> next);
           fprintf(out, "%3d,", top -> lineNum);
        }
     } //end printLineNumbers

     NodeData newNodeData(char str[]) {
        NodeData temp;
        strcpy(temp.word, str);
        temp.firstLine = NULL;
        return temp;
     } //end newNodeData

     ListNodePtr newListNode(int lineNo) {
        ListNodePtr p = (ListNodePtr) malloc(sizeof(ListNode));
        p -> lineNum = lineNo;
        p -> next = NULL;
        return p;
     } //end newListNode

