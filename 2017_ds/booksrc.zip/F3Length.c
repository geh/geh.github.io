        int length(NodePtr top) {
        int n = 0;
        NodePtr curr = top;
        while (curr != NULL) {
           n++;
           curr = curr -> next;
        }
        return n;
     } //end length
