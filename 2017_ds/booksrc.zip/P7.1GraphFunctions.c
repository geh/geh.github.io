// Program P7.1
     #include <stdio.h>
     #include <stdlib.h>
     #include <string.h>

     #define MaxWordSize 20
     #define MaxVertices 50
     #define White 'w'
     #define Gray 'g'
     #define Black 'b'

     typedef struct gEdge {
        int child, weight; //'child' is the location of the child vertex
        struct gEdge *nextEdge;
     } GEdge, *GEdgePtr;

     typedef struct {
        char id[MaxWordSize+1], colour;
        int parent, cost, discover, finish, inDegree;
        GEdgePtr firstEdge;
     } GVertex;

     typedef struct graph {
        int numV;
        GVertex vertex[MaxVertices+1];
     } *Graph;

     int main() {
        int numVertices;
        Graph newGraph(int);
        void buildGraph(FILE *, Graph);
        void printGraph(Graph);
        void depthFirstTraversal(Graph, int);
        void printPath(Graph, char[]);
        FILE * in = fopen("graph.in", "r");

        fscanf(in, "%d", &numVertices);
        Graph G = newGraph(numVertices);
        buildGraph(in, G);
        printGraph(G);
        depthFirstTraversal(G, 1);
        printPath(G, "C");
        fclose(in);
     } // end main

     Graph newGraph(int n) {
        if (n > MaxVertices) {
           printf("\nToo big. Only %d vertices allowed.\n", MaxVertices);
           exit(1);
        }
        Graph p = (Graph) malloc(sizeof(struct graph));
        p -> numV = n;
        return p;
     } //end newGraph

     void buildGraph(FILE * in, Graph G) {
        int numEdges, weight;
        GVertex newGVertex(char[]);
        void addEdge(char[], char[], int, Graph);
        char nodeID[MaxWordSize+1], adjID[MaxWordSize+1];
        for (int h = 1; h <= G -> numV; h++) {
           G -> vertex[h] = newGVertex("");      //create a vertex node
           fscanf(in, "%s", G -> vertex[h].id);   //read the name into id
        }
        for (int h = 1; h <= G -> numV; h++) {
           fscanf(in, "%s %d", nodeID, &numEdges); //parent id and numEdges
           for (int k = 1; k <= numEdges; k++) {
              fscanf(in, "%s %d", adjID, &weight); //get child id and weight
              addEdge(nodeID, adjID, weight, G);
           }
        }
     } //end buildGraph

     GVertex newGVertex(char name[]) {
        GVertex temp;
        strcpy(temp.id, name);
        temp.firstEdge = NULL;
        return temp;
     }

     void addEdge(char X[], char Y[], int weight, Graph G) {
        GEdgePtr newGEdge(int, int);
        //add an edge X -> Y with a given weight
        int h, k;
        //find X in the list of nodes; its location is h
        for (h = 1; h <= G -> numV; h++) if (strcmp(X, G -> vertex[h].id) == 0) break;

        //find Y in the list of nodes; its location is k
        for (k = 1; k <= G-> numV; k++) if (strcmp(Y, G -> vertex[k].id) == 0) break;

        if (h > G -> numV || k > G -> numV) {
           printf("No such edge: %s -> %s\n", X, Y);
           exit(1);
        }

        GEdgePtr ep = newGEdge(k, weight); //create edge vertex
        // add it to the list of edges, possible empty, from X;
        // it is added so that the list is in order by vertex id
        GEdgePtr prev, curr;
        prev = curr = G -> vertex[h].firstEdge;
        while (curr != NULL && strcmp(Y, G -> vertex[curr -> child].id) > 0) {
           prev = curr;
           curr = curr -> nextEdge;
        }

        if (prev == curr) {
           ep -> nextEdge = G -> vertex[h].firstEdge;
           G -> vertex[h].firstEdge = ep;
        }
        else {
           ep -> nextEdge = curr;
           prev -> nextEdge = ep;
        }
     } //end addEdge

     GEdgePtr newGEdge(int c, int w) {
     //return a pointer to a new GEdge node
        GEdgePtr p = (GEdgePtr) malloc(sizeof (GEdge));;
        p -> child = c;
        p -> weight = w;
        p -> nextEdge = NULL;
        return p;
     }

     void printGraph(Graph G) {
        for (int h = 1; h <= G -> numV; h++) {
           printf("%s: ", G -> vertex[h].id);
           GEdgePtr p = G -> vertex[h].firstEdge;
           while (p != NULL) {
              printf("%s %d ", G -> vertex[p -> child].id, p -> weight);
              p = p -> nextEdge;
           }
           printf("\n");
        }
     } //end printGraph

     void depthFirstTraversal(Graph G, int s) {
     //do a depth first traversal of G starting from vertex s
        void dfTraverse(Graph, int);
        for (int h = 1; h <= G -> numV; h++) {
           G -> vertex[h].colour = White;
           G -> vertex[h].parent = 0;
        }
        printf("\nDepth-first traversal starting from %s\n", G -> vertex[s].id);
        dfTraverse(G, s); //start traversal from s
        //check if any White vertices remain; if so, start another traversal
        for (int h = 1; h <= G -> numV; h++)
           if (G -> vertex[h].colour == White) dfTraverse(G, h);
        printf("\n");
     } //end depthFirstTraversal()

     void dfTraverse(Graph G, int s) {
        static int time = 0;  //retains its value between calls
        printf("%s ", G -> vertex[s].id);
        G -> vertex[s].colour = Gray;
        G -> vertex[s].discover = ++time;
        GEdgePtr edge = G -> vertex[s].firstEdge;
        while (edge != NULL) {
           if (G -> vertex[edge -> child].colour == White) {
              G -> vertex[edge -> child].parent = s;
              dfTraverse(G, edge -> child);
           }
           edge = edge -> nextEdge;
        }
        G -> vertex[s].colour = Black;
        G -> vertex[s].finish = ++time;
     } //end dfTraverse

     void printPath(Graph G, char D[]) {
        int h;
        void followPath(Graph, int);
        // find D in the list of nodes (location h)
        for (h = 1; h <= G -> numV; h++)
           if (strcmp(D, G -> vertex[h].id) == 0) break;
        if (h > G -> numV) printf("\nNo such node %s\n", D);
        else {
           printf("\nPath to %s: ", D);
           followPath(G, h);
           printf("\n");
        }
     } //end printPath

     void followPath(Graph G, int c) {
        if (c != 0) {
           followPath(G, G -> vertex[c].parent);
           printf("%s " , G -> vertex[c].id);
        }
     } //end followPath
