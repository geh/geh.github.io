// Program P5.8
     #include <stdio.h>
     #include <string.h>
     #define MaxWordSize 20
     #define MaxNodes 100

     int main() {
        int buildTree(FILE *, char[][MaxWordSize+1], int);
        void preOrder(char[][MaxWordSize+1], int, int);

        FILE * in = fopen("btree.in", "r");
        char T[MaxNodes+1][MaxWordSize+1];

        int n = buildTree(in, T, 1);
        printf("\nThe pre-order traversal is: ");
        preOrder(T, 1, n);
        printf("\n\n");
        fclose(in);
     } // end main

     int buildTree(FILE * in, char T[][MaxWordSize+1], int root) {
        char str[MaxWordSize+1];
        static int lastNode = 0;

        fscanf(in, "%s", str);
        if (strcmp(str, "@") == 0) {
           if (root <= MaxNodes) strcpy(T[root], "*");
           return;
        }
        if (root > MaxNodes) {
           printf("\nArray is too small to hold tree\n");
           exit(1);
        }
        if (root > lastNode) lastNode = root;
        strcpy(T[root], str);
        buildTree(in, T, root * 2);       //build the left subtree
        buildTree(in, T, root * 2 + 1);   //build the right subtree
        return lastNode;
     } //end buildTree

     void visit(char T[][MaxWordSize+1], int node) {
        printf("%s ", T[node]);
     }

     void preOrder(char T[][MaxWordSize+1], int root, int n) {
        //tree is stored in T[1] to T[n]
        void visit(char[][MaxWordSize+1], int);
        if (root <= n && strcmp(T[root], "*") != 0) { //if not null
           visit(T, root);
           preOrder(T, root * 2, n);
           preOrder(T, root * 2 + 1, n);
        }
     } //end preOrder
