// Program P5.6
     #include <stdio.h>
     #define MaxWordSize 20

     typedef struct {
        char word[MaxWordSize+1];
     } NodeData;

     typedef struct treeNode {
        NodeData data;
        struct treeNode *left, *right;
     } TreeNode, *TreeNodePtr;

     typedef struct {
        TreeNodePtr root;
     } BinaryTree;

     typedef struct {
        TreeNodePtr tnode;
     } QueueData;

     #include <queue.h>

     int main() {
        TreeNodePtr buildTree(FILE *);
        void levelOrder(TreeNodePtr);
        FILE * in = fopen("btree.in", "r");
        BinaryTree bt;
        bt.root = buildTree(in);
        printf("\nThe level-order traversal is: ");
        levelOrder(bt.root);
        printf("\n\n");
        fclose(in);
     }

     TreeNodePtr buildTree(FILE * in) {
        char str[MaxWordSize+1];
        fscanf(in, "%s", str);
        if (strcmp(str, "@") == 0) return NULL;
        TreeNodePtr p = (TreeNodePtr) malloc(sizeof(TreeNode));
        strcpy(p -> data.word, str);
        p -> left = buildTree(in);
        p -> right = buildTree(in);
        return p;
     } //end buildTree

     QueueData newQueueData(TreeNodePtr tnp) {
        QueueData temp;
        temp.tnode = tnp;
        return temp;
     } //end newQueueData

     void levelOrder(TreeNodePtr root) {
        QueueData newQueueData(TreeNodePtr);
        Queue Q = initQueue();
        enqueue(Q, newQueueData(root));
        while (!empty(Q)) {
           QueueData temp = dequeue(Q);
           printf("%s ", temp.tnode -> data.word);;
           if (temp.tnode -> left != NULL)
              enqueue(Q, newQueueData(temp.tnode -> left));
           if (temp.tnode -> right != NULL)
              enqueue(Q, newQueueData(temp.tnode -> right));
        } //end while
     } //end levelOrder
