// Program P2.6
     #include <stdio.h>
     int main() {
        double integral(double, double, int, double (*fp)(double));
        double quadratic(double);

        double answer = integral(0, 2, 20, quadratic);
        printf("The value of the integral is %3.2f\n", answer);
     } //end main

     double integral(double a, double b, int n, double (*fp) (double)) {
        double h, sum;
        h = (b - a) / n;
        sum = ((*fp)(a) + (*fp)(b)) / 2.0;
        for (int i = 1; i < n ; i++)
           sum += (*fp)(a + i * h);
        return h * sum;
     } //end integral

     double quadratic(double x) {
        return x * x + 5.0 * x + 3.0;
     }
