     NodePtr search(NodePtr top, int key) {
        while (top != NULL && key != top -> num)
           top = top -> next;
        return top;
     } //end search
